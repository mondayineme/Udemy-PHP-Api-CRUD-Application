<?php
// include headers
// Allowing access from any domain
header("Access-Control-Allow-Origin: *");

// it allow all origins like localhost, any domain or any subdomain
// This line of code allowed data to be entered in JSON Format
header("Content-type: application/json; charset=UTF-8");

// data which we are getting inside request
// This line of code only allow a POST Request method
header("Access-Control-Allow-Methods: POST");
// method type

// include database.php
include_once("../config/database.php");
// include student.php
include_once("../classes/students.php");

// create object for database
$db = new Database();

$connection = $db->connect();

// create object for student
$student = new Student($connection);

if($_SERVER['REQUEST_METHOD'] === "POST"){

// This line of code means that when data is entered in JSON, it is being converted to PHP object
// in order to be stored in the database
  $data = json_decode(file_get_contents("php://input"));

  if(!empty($data->name) && !empty($data->email) && !empty($data->mobile)){
    // submit data
    // The $data variable let the input to be converted to PHP object before is being stored in the database.
    $student->name = $data->name;
    $student->email = $data->email;
    $student->mobile = $data->mobile;

    if($student->create_data()){

      http_response_code(200); //200 means ok
      // Then at this point the data is being converted back to JSON in order for it to be displayed in JSON format
      echo json_encode(array(
        "status" => 1,
        "message" => "Student has been created"
      ));
    }else{

      http_response_code(500); //500 means internal server error
      // Then at this point the data is being converted back to JSON in order for it to be displayed in JSON format
      echo json_encode(array(
        "status" => 0,
        "message" => "Failed to create student"
      ));
    }
  }
  else{
    http_response_code(404); //404 means page not found
    // Then at this point the data is being converted back to JSON in order for it to be displayed in JSON format
    echo json_encode(array(
      "status" => 0,
      "message" => "All values needed"
    ));
  }
}else{

  http_response_code(503); //500 means service unavialable
  // Then at this point the data is being converted back to JSON in order for it to be displayed in JSON format
  echo json_encode(array(
    "status" => 0,
    "message" => "Access denied"
  ));
}
 ?>
