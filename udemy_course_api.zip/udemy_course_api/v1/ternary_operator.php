<?php

// This is called Ternary Operator
// This is another type of if else condition statement


$marks=40;

// If mark is equal or greater than 40 then print pass else print failed
if ($mark>=40) {
    print("pass");
} else {
    print("Failed");
}

// If mark is equal or greater than 40 then print pass else print failed
print ($marks>=40) ? "pass" : "Fail";

//Similarly

// Normal If else condition
if ($student_id == isset($_GET['id'])) {
    $_GET['id']; // Get the id as GET Method.
} else {
    ""// Null value
}

// Ternary Operator conditional statement
$student_id = isset($_GET['id']) ? $_GET['id'] : "";

 
?>